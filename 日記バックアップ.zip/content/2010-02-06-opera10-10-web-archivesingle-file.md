---
title: Opera10.10 Web archive(single file)
author: hiroyuki_t
layout: post
date: 2010-02-06T00:13:20+00:00
url: /2010/02/06/091320/
categories:
  - Opera
  - Ubuntu

---
<div class="section">
  <p>
    Ubuntu 9.10でOpera10.10を自分の環境で動かすと
  </p>
  
  <p>
    言語設定によって処理が異なっている
  </p>
  
  <p>
    [ファイル]→[保存]→[Webアーカイブ(単一ファイル)](/usr/share/opera/locale/ja/ja.lng)を選ぶと拡張子がmhtにならない。
  </p>
  
  <p>
    [File]→[Save As]→[Web archive(single file)](/usr/share/opera/locale/en/en.lng)だと拡張子がmhtになる。
  </p>
  
  <p>
    処理も異なる模様
  </p>
  
  <p>
  </p>
  
  <p>
    追記
  </p>
  
  <p>
    日本語での問題点についてもう少し試して見たところ
  </p>
  
  <p>
    拡張子がmhtにならないではなく
  </p>
  
  <p>
    拡張子が変わらないというのが正しい。
  </p>
  
  <p>
    htmlにしてもtxtにしても拡張子が変わらない。
  </p>
  
  <p>
    デフォルトのままとなる。
  </p>
</div>