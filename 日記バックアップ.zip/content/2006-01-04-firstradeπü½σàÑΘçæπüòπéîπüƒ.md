---
title: Firstradeに入金された
author: hiroyuki_t
layout: post
date: 2006-01-04T12:19:43+00:00
url: /2006/01/04/211943/
categories:
  - 投資

---
<div class="section">
  <p>
    Firstradeに入金されたようです。
  </p>
  
  <p>
    988ドル入っていました。
  </p>
  
  <p>
    12ドルは手数料だと思われます。
  </p>
  
  <p>
  </p>
  
  <p>
    郵便局から送金用紙が送られてきたら
  </p>
  
  <p>
    早速追加資金を投入したいところです。
  </p>
</div>