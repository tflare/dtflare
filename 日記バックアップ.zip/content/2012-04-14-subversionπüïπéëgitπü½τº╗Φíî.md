---
title: SubversionからGitに移行
author: hiroyuki_t
layout: post
date: 2012-04-13T22:09:56+00:00
url: /2012/04/14/070956/
categories:
  - Prog

---
<div class="section">
  <p>
    公開できる品質ではないソースを
  </p>
  
  <p>
    git-svnを使用してSubversionからGitに移行し、Bitbucketにprivateで上げた。
  </p>
  
  <p>
  </p>
  
  <p>
    テストとして、GitHubにソースを上げたかったので、
  </p>
  
  <p>
    古いソース（2005年）をGitHubに上げた。
  </p>
  
  <p>
    <a href="https://github.com/tflare" target="_blank">https://github.com/tflare</a>
  </p>
</div>