---
title: Vivaldiの設定を別のMacへコピーする方法
author: hiroyuki_t
layout: post
date: 2016-03-29T13:53:35+00:00
url: /2016/03/29/225335/
categories:
  - Mac
  - Vivaldi

---
Vivaldiの設定を別のMacへコピーする方法
  
（bata3同士での動作を確認しています。
  
　確認していませんが、bataからスナップショットへの設定の移行もできると思われます。）

手順1
  
/Users/[ユーザ名]/Library/Application Support/Vivaldi/Default
  
に設定ファイルが存在するので、フォルダごと、コピーする。
  
[ユーザ名]は自分のユーザ名

手順2
  
手順1のデータをコピー先に移送する。
  
（この際、Vivaldiが終了していることを確認する。）