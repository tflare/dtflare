---
title: firstradeのチャート
author: hiroyuki_t
layout: post
date: 2006-05-22T14:19:32+00:00
url: /2006/05/22/231932/
categories:
  - 投資

---
<div class="section">
  <p>
    firstradeのチャート眺めてたら
  </p>
  
  <p>
    チャートが15分遅れな事に気づいた。
  </p>
  
  <p>
    無料のツールを入れればリアルタイムで見れるらしいけどツールをあまりいれたくない。
  </p>
  
  <p>
  </p>
  
  <p>
    リアルタイムの価格情報は、
  </p>
  
  <p>
    Yahoo! FinanceでReal-Time ECNで見るか
  </p>
  
  <p>
    Google英語版でティッカーで検索するとReal-Time ECNで見れる。
  </p>
  
  <p>
    チャートは見れないけど
  </p>
</div>