---
title: Cordless Desktop EX 100のマウスの電池
author: hiroyuki_t
layout: post
date: 2010-03-14T13:17:19+00:00
url: /2010/03/14/221719/
categories:
  - Other

---
<div class="section">
  <p>
    Cordless Desktop EX 100のマウスの電池が2/6から使い始めて3/14で使えなくなった。
  </p>
  
  <p>
    電池を入れっぱなしだからだろうけどちょっと早すぎる。
  </p>
  
  <p>
    電池はSANYO NEW eneloop 充電器 単3形4個セット (単3形・単4形兼用) N-TGN01AS
  </p>
  
  <p>
    についている単3電池を使用している。
  </p>
</div>