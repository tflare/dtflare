---
title: Google Finance
author: hiroyuki_t
layout: post
date: 2006-05-03T15:00:00+00:00
url: /2006/05/04/000000/
categories:
  - 投資

---
<div class="section">
  <p>
    いつのまにか<a href="http://www.google.com/finance" target="_blank">Google Finance</a>というのが出来ていたらしい
  </p>
  
  <p>
    <a href="http://finance.yahoo.com/" target="_blank">Yahoo! Finance</a>ではティッカーでしか検索できないのが
  </p>
  
  <p>
    <a href="http://www.google.com/finance" target="_blank">Google Finance</a>では会社名でも検索できるので便利
  </p>
  
  <p>
    &nbsp;
  </p>
  
  <p>
    チャートが高機能な上に、ニュースと連動している。
  </p>
  
  <p>
    自分的には会社名検索が出来るのが助かる。
  </p>
</div>