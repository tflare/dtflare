---
title: iMac 21.5インチとMacBook Air 13インチ購入
author: hiroyuki_t
layout: post
date: 2016-03-30T22:12:48+00:00
url: /2016/03/31/071248/
categories:
  - Comp
  - Mac

---
iMac 21.5インチとMacBook Air 13インチ購入

15インチのノートを単独で使用していたが
  
家での使用率が多いため、据え置きと移動用に分けた。
  
また、Macを使用してみたかったのと使いたいソフトがMacにしかないといったことがあったため導入

iMac 21.5インチ LATE 2015

  * 2.8GHz QC i5, TB up to 3.3GHz
  * Intel Iris Pro Graphics 6200
  * 8GB 1867MHz LPDDR3 onboard
  * 256GB Flash Storage

MacBook Air 13インチ EARLY 2015

  * 1.6GHz Intel Dual-Core Core i5
  * Intel HD Graphics 6000
  * 8GB 1600MHz LPDDR3 SDRAM
  * 256GB PCIe-based Flash Storage