---
title: Seagate HDD
author: hiroyuki_t
layout: post
date: 2009-01-25T11:26:39+00:00
url: /2009/01/25/202639/
categories:
  - Comp

---
<div class="section">
  <p>
    Seagate HDDの新情報が来てる
  </p>
  
  <p>
    <a href="http://seagate.custkb.com/seagate/crm/selfservice/search.jsp?DocId=207931" target="_blank">http://seagate.custkb.com/seagate/crm/selfservice/search.jsp?DocId=207931</a>
  </p>
  
  <p>
  </p>
  
  <p>
    前のチェッカーはaffected だったけど今回は not affected
  </p>
  
  <p>
    <a href="https://apps1.seagate.com/rms_af_srl_chk/" target="_blank">https://apps1.seagate.com/rms_af_srl_chk/</a>
  </p>
  
  <p>
  </p>
  
  <p>
    ファームウエアCC2Fなので、バージョンアップできるファームも<a href="http://seagate.custkb.com/seagate/crm/selfservice/search.jsp?DocId=207957" target="_blank">ない</a>。
  </p>
  
  <p>
    ファームウエアCC2Fであれば、ロックはしないようなので、バックアップを取り使用を続けることにします。
  </p>
</div>