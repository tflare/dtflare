---
title: RabbitVCSとFileZilla
author: hiroyuki_t
layout: post
date: 2011-01-14T13:29:23+00:00
url: /2011/01/14/222923/
categories:
  - Prog

---
<div class="section">
  <p>
    RabbitVCSはLinux用TortoiseSVN風のバージョン管理システム
  </p>
  
  <p>
    昔TortoiseSVNを使っていたので、TortoiseSVNがないと開発がやりたくない状態になっていた。
  </p>
  
  <p>
    最近rubyでの開発を再開したのでLinux用のバージョン管理システムを探していたところ
  </p>
  
  <p>
    RabbitVCSを発見した。
  </p>
  
  <p>
    これで開発が存分にできる。
  </p>
  
  <p>
  </p>
  
  <p>
    それとftpツールはFileZillaを使うように変更した。
  </p>
</div>