---
title: Ubuntu 7.04 (Feisty Fawn)
author: hiroyuki_t
layout: post
date: 2007-04-20T13:21:06+00:00
url: /2007/04/20/222106/
categories:
  - Ubuntu

---
<div class="section">
  <p>
    下記を見るとどのような変更が入ったのかわかる。
  </p>
  
  <p>
    BetaのPreviewだけど
  </p>
  
  <p>
    <a href="http://onlyubuntu.blogspot.com/2007/03/ubuntu-704-feisty-fawn-beta-preview.html" target="_blank">http://onlyubuntu.blogspot.com/2007/03/ubuntu-704-feisty-fawn-beta-preview.html</a>
  </p>
  
  <p>
  </p>
  
  <p>
    参考になりそうなところをリンク
  </p>
  
  <p>
  </p>
  
  <p>
    Ubuntu 7.04ではNTFSに読み書き可能になったようです。
  </p>
  
  <p>
    <a href="https://help.ubuntu.com/community/MountingWindowsPartitions" target="_blank">https://help.ubuntu.com/community/MountingWindowsPartitions</a>
  </p>
  
  <p>
  </p>
  
  <p>
    後は以下の検索結果が参考になる。
  </p>
  
  <p>
    <a href="https://help.ubuntu.com/community/UserDocumentation?action=fullsearch&#038;context=180&#038;value=7.04&#038;fullsearch=%E3%83%86%E3%82%AD%E3%82%B9%E3%83%88" target="_blank">https://help.ubuntu.com/community/UserDocumentation?action=fullsearch&context=180&value=7.04&fullsearch=%E3%83%86%E3%82%AD%E3%82%B9%E3%83%88</a>
  </p>
  
  <p>
  </p>
  
  <p>
    以下のようなものがある。
  </p>
  
  <p>
  </p>
  
  <p>
    PlayStation 3
  </p>
  
  <p>
    <a href="https://help.ubuntu.com/community/PlayStation_3?highlight=%287.04%29" target="_blank">https://help.ubuntu.com/community/PlayStation_3?highlight=%287.04%29</a>
  </p>
  
  <p>
  </p>
  
  <p>
    Sun Java6
  </p>
  
  <p>
    <a href="https://help.ubuntu.com/community/Java?highlight=%287.04%29" target="_blank">https://help.ubuntu.com/community/Java?highlight=%287.04%29</a>
  </p>
</div>