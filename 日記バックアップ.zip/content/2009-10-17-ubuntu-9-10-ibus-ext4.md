---
title: Ubuntu 9.10 iBus ext4
author: hiroyuki_t
layout: post
date: 2009-10-17T12:03:34+00:00
url: /2009/10/17/210334/
categories:
  - Ubuntu

---
<div class="section">
  <p>
    VirtualBox上のUbuntu 9.10 betaでiBusは問題なく動いている。
  </p>
  
  <p>
    Opera10.10(opera_10.10.4665.gcc4.qt3_i386.deb)上でも問題なし。
  </p>
  
  <p>
    iBusでいけそう。
  </p>
  
  <p>
  </p>
  
  <p>
    ext4はfsckの高速化がどうなっているのか気になる。
  </p>
  
  <p>
    自分の場合Ubuntu9.04で33回マウントされるとfsckが走っているので
  </p>
  
  <p>
    それが高速化されればうれしいが、変えるほどではないか。
  </p>
  
  <p>
    今のところ見送りで
  </p>
</div>