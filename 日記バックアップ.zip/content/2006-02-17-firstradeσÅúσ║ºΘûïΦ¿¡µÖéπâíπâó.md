---
title: Firstrade口座開設時メモ
author: hiroyuki_t
layout: post
date: 2006-02-17T13:01:49+00:00
url: /2006/02/17/220149/
categories:
  - 投資

---
<div class="section">
  <p>
    Firstrade
  </p>
  
  <p>
    <a href="http://www.firstrade.com/" target="_blank">http://www.firstrade.com/</a>
  </p>
  
  <p>
    注意しなくてはいけないことは以下の二つです。
  </p>
  
  <p>
  </p>
  
  <ul>
    <li>
      プリンタを用意する。
    </li>
  </ul>
  
  <p>
    プリンタがなくても出来るけど、ないとめんどくさい。
  </p>
  
  <p>
    自分は申し込むために買いました。
  </p>
  
  <p>
    申し込み時に持っておいたほうがよいです。
  </p>
  
  <p>
    自分は申し込んでからプリンタを買ったのでめんどくさかったです。
  </p>
  
  <ul>
    <li>
      パスポートを用意する。
    </li>
  </ul>
  
  <p>
    申し込み時にパスポートがないと申し込みが出来ない。
  </p>
  
  <p>
  </p>
  
  <p>
    細かい手順は以下を参照
  </p>
  
  <p>
    ココロの米国株投資
  </p>
  
  <p>
    <a href="http://www.fides.dti.ne.jp/~soleil/top.html" target="_blank">http://www.fides.dti.ne.jp/~soleil/top.html</a>
  </p>
  
  <p>
    W-8BENの記入方法
  </p>
  
  <p>
    <a href="http://www.alt-invest.com/w8ben/" target="_blank">http://www.alt-invest.com/w8ben/</a>
  </p>
</div>