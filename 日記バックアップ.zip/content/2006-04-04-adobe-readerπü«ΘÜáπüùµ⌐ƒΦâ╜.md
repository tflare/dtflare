---
title: Adobe Readerの隠し機能
author: hiroyuki_t
layout: post
date: 2006-04-04T12:26:12+00:00
url: /2006/04/04/212612/
categories:
  - Comp

---
<div class="section">
  <p>
    Adobe LiveCycle Reader Extensions
  </p>
  
  <p>
    <a href="http://www.adobe.co.jp/products/server/readerextensions/overview.html" target="_blank">http://www.adobe.co.jp/products/server/readerextensions/overview.html</a>
  </p>
  
  <blockquote>
    <p>
      Reader Extensionsでは、Adobe PDFドキュメントに特別な利用権限を設定できます。 この利用権限によって無償のAdobe Readerが持つ「隠し機能」が起動する。
    </p>
  </blockquote>
  
  <p>
    Adobe Readerに隠し機能なんて含まれていたのか。
  </p>
  
  <p>
    知らなかった。
  </p>
  
  <p>
  </p>
  
  <p>
    J2EEを拡張するAdobe LiveCycleの全容
  </p>
  
  <p>
    <a href="http://www.atmarkit.co.jp/fwcr/rensai/pdf02/pdf02_2.html" target="_blank">http://www.atmarkit.co.jp/fwcr/rensai/pdf02/pdf02_2.html</a>
  </p>
  
  <p>
    上記によるとフォーム記入内容の保存、コメント付与、ファイル添付等が出来るらしい。
  </p>
</div>