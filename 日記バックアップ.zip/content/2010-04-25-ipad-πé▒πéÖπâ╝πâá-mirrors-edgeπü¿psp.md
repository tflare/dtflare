---
title: iPad ゲーム Mirror’s EdgeとPSP
author: hiroyuki_t
layout: post
date: 2010-04-25T01:51:41+00:00
url: /2010/04/25/105141/
categories:
  - Other

---
<div class="section">
  <p>
    iPad Games Walkthrough &#8212; Mirror&#8217;s Edge, Geometry Wars: Touch, Plants vs. Zombies
  </p>
  
  <p>
    <a href="http://g4tv.com/thefeed/blog/post/703777/ipad-games-walkthrough----mirrors-edge-plants-vs-zombies-hd-geometry-wars-touch.html" target="_blank">http://g4tv.com/thefeed/blog/post/703777/ipad-games-walkthrough&#8212;-mirrors-edge-plants-vs-zombies-hd-geometry-wars-touch.html</a>
  </p>
  
  <p>
  </p>
  
  <p>
    4:22～の
  </p>
  
  <p>
    Mirror&#8217;s Edgeがおもしろそう
  </p>
  
  <p>
    操作感がとても直感的に見える。
  </p>
  
  <p>
  </p>
  
  <p>
    ゲームを売りにきたらPSPは厳しい立場になりそう。
  </p>
  
  <p>
    PSPは画面の綺麗さとディスプレイの広さを重視する人が多そうだけど
  </p>
  
  <p>
    倍以上違う。
  </p>
  
  <p>
    PSP:4.3インチディスプレイ
  </p>
  
  <p>
    iPad:9.7インチディスプレイ
  </p>
  
  <p>
  </p>
  
  <p>
    iPadとPSP（2万円程度）は価格が違い、
  </p>
  
  <p>
    iPadはこどもが買うのに厳しい値段であることから
  </p>
  
  <p>
    こどもに一般的な普及をさせるのは難しいと思われるが
  </p>
  
  <p>
    ゲームソフトを充実させた上で将来の大幅な値下げがあれば
  </p>
  
  <p>
    強力な対抗となりうると思われる。
  </p>
  
  <p>
  </p>
  
  <p>
    iPad価格はWi-Fiモデルの16Gバイト版が499ドル、32Gバイト版が599ドル、64Gバイト版が699ドル
  </p>
  
  <p>
  </p>
  
  <p>
    The Apple iPad: starting at $499
  </p>
  
  <p>
    <a href="http://www.engadget.com/2010/01/27/the-apple-ipad/" target="_blank">http://www.engadget.com/2010/01/27/the-apple-ipad/</a>
  </p>
</div>