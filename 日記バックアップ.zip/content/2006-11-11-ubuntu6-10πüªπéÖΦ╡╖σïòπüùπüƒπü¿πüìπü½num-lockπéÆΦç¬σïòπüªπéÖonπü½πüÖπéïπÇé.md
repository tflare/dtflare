---
title: Ubuntu6.10で起動したときにNum Lockを自動でONにする。
author: hiroyuki_t
layout: post
date: 2006-11-10T15:00:00+00:00
url: /2006/11/11/000000/
categories:
  - Ubuntu

---
<div class="section">
  <p>
    以下を参考にして設定するとNum Lockを自動でONにできた。
  </p>
  
  <p>
    <a href="http://ubuntuguide.org/wiki/Ubuntu_dapper_Ja#How_to_turn_on_Num_Lock_on_GNOME_startup" target="_blank">How_to_turn_on_Num_Lock_on_GNOME_startup</a>
  </p>
</div>