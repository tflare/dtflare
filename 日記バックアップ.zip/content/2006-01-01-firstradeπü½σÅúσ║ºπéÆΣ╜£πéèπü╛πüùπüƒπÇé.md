---
title: Firstradeに口座を作りました。
author: hiroyuki_t
layout: post
date: 2006-01-01T11:20:48+00:00
url: /2006/01/01/202048/
categories:
  - 投資

---
<div class="section">
  <p>
    Firstradeに口座を作りました。
  </p>
  
  <p>
    手数料が安そうだったので。
  </p>
  
  <p>
  </p>
  
  <p>
    郵便局からとりあえず1000ドル送ってみました。
  </p>
  
  <p>
    以下のページが参考になりました。
  </p>
  
  <p>
    <a href="http://www.interq.or.jp/world/shopping/wt2us.htm" target="_blank">http://www.interq.or.jp/world/shopping/wt2us.htm</a>
  </p>
  
  <p>
  </p>
  
  <p>
    ぱるるからの送金の場合用紙の左下のところに
  </p>
  
  <p>
    必要部数を書けば住所とかが書かれた用紙を自宅に送ってくれるようです。
  </p>
  
  <p>
    便利です。
  </p>
  
  <p>
  </p>
  
  <p>
    アメリカの株はよくわからないので
  </p>
  
  <p>
    Vanguard Prc Mtl&M;Inv(Symbol:VGPMX)
  </p>
  
  <p>
    というレアメタル系ファンドを買う予定です。
  </p>
</div>