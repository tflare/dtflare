---
title: Firstrade送金時メモ
author: hiroyuki_t
layout: post
date: 2006-02-18T13:02:31+00:00
url: /2006/02/18/220231/
categories:
  - 投資

---
<div class="section">
  <p>
    以下を参照して下さい。
  </p>
  
  <p>
    郵便局から米国の銀行へ送金する方法
  </p>
  
  <p>
    <a href="http://www.interq.or.jp/world/shopping/wt2us.htm" target="_blank">http://www.interq.or.jp/world/shopping/wt2us.htm</a>
  </p>
  
  <p>
  </p>
  
  <p>
    国際郵便振替請求書兼告知書記入方法
  </p>
  
  <p>
    送金種類は銀行口座あて送金
  </p>
  
  <p>
    送金方法は下記のページを見て値段と期間によって検討する。
  </p>
  
  <p>
    ただし平成18年4月3日から値段が変更されるので注意
  </p>
  
  <p>
    <a href="http://www.yu-cho.japanpost.jp/s0000000/ssk20300.htm" target="_blank">http://www.yu-cho.japanpost.jp/s0000000/ssk20300.htm</a>
  </p>
  
  <p>
    受取人　氏名　　　ADP CLEARING
  </p>
  
  <p>
    　　　　住所　　　55 WATER STREET 32ND FLOOR
  </p>
  
  <p>
    　　　　　　　　　NEW YORK NY 10041
  </p>
  
  <p>
    　　　　郵便番号　空欄で可
  </p>
  
  <p>
    　　　　あて先国　USA
  </p>
  
  <p>
    　　　　受取人口座番号 8661169975
  </p>
  
  <p>
    銀行口座あて送金の場合
  </p>
  
  <p>
    　　　　受取銀行　　BANK OF NEW YORK
  </p>
  
  <p>
    　　　　支店名　　　空欄で可
  </p>
  
  <p>
    　　　　銀行の住所　空欄で可
  </p>
  
  <p>
    　　　　銀行コード　//FW021000018
  </p>
  
  <p>
    差出人　自分の情報を書く
  </p>
  
  <p>
    通信文　ここに自分の情報を書いておく
  </p>
  
  <p>
    通貨コード USD
  </p>
  
  <p>
    本請求用紙の送付をご希望の場合の欄で部数を書いておくと
  </p>
  
  <p>
    上記が書かれた状態の用紙を送ってくれる。
  </p>
</div>