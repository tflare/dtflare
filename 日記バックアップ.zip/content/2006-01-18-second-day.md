---
title: Second Day
author: hiroyuki_t
layout: post
date: 2006-01-18T08:31:27+00:00
url: /2006/01/18/173127/
categories:
  - 未分類

---
<div class="section">
  <p>
    Japanese Stocks Plunge for Second Day
  </p>
  
  <p>
    <a href="http://biz.yahoo.com/ap/060118/japan_markets.html?.v=6" target="_blank">http://biz.yahoo.com/ap/060118/japan_markets.html?.v=6</a>
  </p>
  
  <p>
    Yahooのトップにこんな記事が
  </p>
  
  <p>
    ここまで下がると来週あたりには業績好調銘柄の買い時が来ると思われる。
  </p>
  
  <p>
    日本市場に注目しておこう。
  </p>
</div>