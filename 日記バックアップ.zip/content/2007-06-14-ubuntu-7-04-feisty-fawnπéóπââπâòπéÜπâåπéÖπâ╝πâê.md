---
title: Ubuntu 7.04 (Feisty Fawn)アップデート
author: hiroyuki_t
layout: post
date: 2007-06-14T13:41:18+00:00
url: /2007/06/14/224118/
categories:
  - Ubuntu

---
<div class="section">
  <p>
    アップデートマネジャーでアップデート
  </p>
  
  <p>
    /etc/apt/sources.listから
  </p>
  
  <p>
    以下のアップデートの際にコメントアウトされたの行を有効にする。
  </p>
  
  <p>
    deb <a href="http://deb.opera.com/opera" target="_blank">http://deb.opera.com/opera</a> stable non-free
  </p>
  
  <p>
  </p>
  
  <p>
    意外とあっさりと終わった。
  </p>
  
  <p>
  </p>
  
  <p>
    その後日本語版セットアップヘルパでAcrobat ReaderとAcrobat Reader用IPAフォントを入れたら
  </p>
  
  <p>
    /etc/apt/sources.listに以下が追加されたので削除した。
  </p>
  
  <p>
    deb <a href="http://archive.ubuntulinux.jp/ubuntu-ja" target="_blank">http://archive.ubuntulinux.jp/ubuntu-ja</a> edgy/
  </p>
  
  <p>
    deb <a href="http://archive.ubuntulinux.jp/ubuntu-ja" target="_blank">http://archive.ubuntulinux.jp/ubuntu-ja</a> edgy-ja/
  </p>
</div>