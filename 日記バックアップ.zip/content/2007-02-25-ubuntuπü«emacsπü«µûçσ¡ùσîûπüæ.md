---
title: Ubuntuのemacsの文字化け
author: hiroyuki_t
layout: post
date: 2007-02-24T15:00:00+00:00
url: /2007/02/25/000000/
categories:
  - Ubuntu

---
<div class="section">
  <p>
    emacs21を入れたら文字化けしてどうにもならない状態だったのだが
  </p>
  
  <p>
    下記を参考にしたら直った。
  </p>
  
  <p>
    <a href="http://d.hatena.ne.jp/treeham/20061120" target="_blank">http://d.hatena.ne.jp/treeham/20061120</a>
  </p>
</div>