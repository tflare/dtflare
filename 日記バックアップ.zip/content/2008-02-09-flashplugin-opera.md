---
title: flashplugin Opera
author: hiroyuki_t
layout: post
date: 2008-02-08T23:56:39+00:00
url: /2008/02/09/085639/
categories:
  - Opera
  - Ubuntu

---
<div class="section">
  <p>
    flashplugin-nonfreeのアップデートでflashplugin 9.0.115にアップデートされたが
  </p>
  
  <p>
    Opera 9.50 Beta 2でないと対応してないようなので
  </p>
  
  <p>
    以下を参考に
  </p>
  
  <p>
    <a href="http://ubuntuforums.org/showthread.php?t=688707" target="_blank">http://ubuntuforums.org/showthread.php?t=688707</a>
  </p>
  
  <p>
  </p>
  
  <p>
    以下からflashplugin 9.0.48をダウンロードして入れ直した。
  </p>
  
  <p>
    <a href="http://andyv133.homelinux.org/downloads/install_flash_player_9r48_linux.tar.gz" target="_blank">http://andyv133.homelinux.org/downloads/install_flash_player_9r48_linux.tar.gz</a>
  </p>
</div>