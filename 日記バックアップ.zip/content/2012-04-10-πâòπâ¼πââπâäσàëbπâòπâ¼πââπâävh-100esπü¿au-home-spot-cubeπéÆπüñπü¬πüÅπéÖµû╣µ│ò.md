---
title: 'フレッツ光/Bフレッツ(VH-100E<S>)とau HOME SPOT CUBEをつなぐ方法'
author: hiroyuki_t
layout: post
date: 2012-04-09T20:50:14+00:00
url: /2012/04/10/055014/
categories:
  - Comp

---
<div class="section">
  <p>
    <a href="http://www.cs-au.com/3m%E9%96%A2%E9%80%A3/wi-fi-home/home-spot-cube/" target="_blank">http://www.cs-au.com/3m%E9%96%A2%E9%80%A3/wi-fi-home/home-spot-cube/</a>
  </p>
  
  <p>
    のケース２
  </p>
  
  <p>
    無線でつながっている端末からHOME SPOT CUBEの設定画面にアクセス
  </p>
  
  <p>
    PPPoEでの設定が必要
  </p>
  
  <p>
    PPPoE設定の際のユーザ名についてはniftyの場合、@nifty.comを忘れないように注意。
  </p>
</div>